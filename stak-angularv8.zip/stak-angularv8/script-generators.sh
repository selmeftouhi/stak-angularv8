#!/bin/bash


# Modules part

#ng g m ./modules/home --routing


# Components part

# Services part

ng g s ./shared/services/user

# Pipes part

# Directives part
