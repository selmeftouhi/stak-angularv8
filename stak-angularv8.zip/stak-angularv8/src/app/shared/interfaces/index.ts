export * from './paginate.pattern.interface';
export * from './dao.pattern.interface';
